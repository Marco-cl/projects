from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.sql import text

app = Flask(__name__)

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:postgres@localhost/postgres'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Models
class Student(db.Model):
    __tablename__ = 'student'
    matricno = db.Column(db.String, primary_key=True)
    firstname = db.Column(db.String)
    lastname = db.Column(db.String)
    address = db.Column(db.String)
    dob = db.Column(db.Date)
    sex = db.Column(db.String)
    financialloan = db.Column(db.Float)
    courseid = db.Column(db.String)

class Course(db.Model):
    __tablename__ = 'course'
    courseid = db.Column(db.String, primary_key=True)
    title = db.Column(db.String)

# Routes
@app.route('/')
def home():
    return render_template('home.html')

# CRUD for Students
@app.route('/students')
def students():
    students = Student.query.all()
    return render_template('students.html', students=students)

@app.route('/add_student', methods=['GET', 'POST'])
def add_student():
    courses = Course.query.all()
    if request.method == 'POST':
        # Validate financialloan
        if float(request.form['financialloan']) >= 10**8:
            return "Financial Loan exceeds the maximum allowed value.", 400
        
        # Add the new student
        new_student = Student(
            matricno=request.form['matricno'],
            firstname=request.form['firstname'],
            lastname=request.form['lastname'],
            address=request.form['address'],
            dob=request.form['dob'],
            sex=request.form['sex'],
            financialloan=request.form['financialloan'],
            courseid=request.form['courseid']
        )
        db.session.add(new_student)
        db.session.commit()
        return redirect(url_for('students'))
    return render_template('add_student.html', courses=courses)

@app.route('/edit_student/<string:matricno>', methods=['GET', 'POST'])
def edit_student(matricno):
    student = Student.query.get(matricno)
    courses = Course.query.all()
    if request.method == 'POST':
        student.firstname = request.form['firstname']
        student.lastname = request.form['lastname']
        student.address = request.form['address']
        student.dob = request.form['dob']
        student.sex = request.form['sex']
        student.financialloan = request.form['financialloan']
        student.courseid = request.form['courseid']
        db.session.commit()
        return redirect(url_for('students'))
    return render_template('edit_student.html', student=student, courses=courses)

@app.route('/delete_student/<string:matricno>', methods=['POST'])
def delete_student(matricno):
    student = Student.query.get(matricno)
    db.session.delete(student)
    db.session.commit()
    return redirect(url_for('students'))

if __name__ == '__main__':
    app.run(debug=True)
