-- (a) List details of all departments located in E Block
SELECT *
FROM department
WHERE location = 'E Block';

-- (b) List title, start, and end dates of all modules run in the PgDIT course
SELECT m.moduletitle AS title, 
       m.startdate AS start_date, 
       m.startdate + INTERVAL '3 months' AS end_date
FROM module m
JOIN course c ON m.courseid = c.courseid
WHERE c.title = 'PgDIT';

-- (c) List name, address, and salary for each female member of academic staff who manages a department
SELECT a.firstname || ' ' || a.lastname AS name, 
       a.address, 
       a.salary
FROM academicstaff a
JOIN department d ON a.staffno = d.managerstaffno
WHERE a.sex = 'F';

-- (d) List name, sex, and salary for each lecturer with a PhD degree
SELECT a.firstname || ' ' || a.lastname AS name, 
       a.sex, 
       a.salary
FROM academicstaff a
WHERE a.post = 'Lecturer' AND a.qualifications ILIKE '%PhD%';

-- (e) List last name, post, and qualifications of all members of academic staff who are employed by CIS department
SELECT a.lastname, 
       a.post, 
       a.qualifications
FROM academicstaff a
JOIN department d ON a.departmentid = d.departmentid
WHERE d.name = 'CIS';

-- (f) List matriculation number, last name, and sex of all students who are studying 'multi-media' module
-- Order result alphabetically by last name
SELECT s.matricno, 
       s.lastname, 
       s.sex
FROM student s
JOIN student_module sm ON s.matricno = sm.matricno
JOIN module m ON sm.moduleid = m.moduleid
WHERE m.moduletitle = 'multi-media'
ORDER BY s.lastname;

-- (g) List staff number, last name, sex, and post of all academic staff whose salary is greater than the average salary
SELECT staffno, 
       lastname, 
       sex, 
       post
FROM academicstaff
WHERE salary > (SELECT AVG(salary) FROM academicstaff);

-- (h) For each course with more than 10 students, list course title and the number of students
SELECT c.title AS course_title, 
       COUNT(s.matricno) AS number_of_students
FROM course c
JOIN student s ON c.courseid = s.courseid
GROUP BY c.courseid, c.title
HAVING COUNT(s.matricno) > 10;

-- (i) List the number of female and male academic staff employed by CIS department
SELECT d.name AS department_name, 
       SUM(CASE WHEN a.sex = 'F' THEN 1 ELSE 0 END) AS female_staff_count, 
       SUM(CASE WHEN a.sex = 'M' THEN 1 ELSE 0 END) AS male_staff_count
FROM academicstaff a
JOIN department d ON a.departmentid = d.departmentid
WHERE d.name = 'CIS'
GROUP BY d.name;

-- (j) For each academic staff who spends more than 6 hours teaching any module, list their last name, module title, and hours
SELECT a.lastname AS academic_lastname, 
       m.moduletitle AS module_title, 
       am.teachinghours AS hours_taught
FROM academicstaff_module am
JOIN academicstaff a ON am.staffno = a.staffno
JOIN module m ON am.moduleid = m.moduleid
WHERE am.teachinghours > 6;

-- (k) For each department, list the department name, number of female and male staff (crosstab query)
CREATE EXTENSION IF NOT EXISTS tablefunc;

SELECT * FROM crosstab(
    $$
    SELECT d.name AS department_name, 
           a.sex, 
           COUNT(*) AS staff_count
    FROM academicstaff a
    JOIN department d ON a.departmentid = d.departmentid
    GROUP BY d.name, a.sex
    ORDER BY d.name, a.sex
    $$,
    $$ VALUES ('F'), ('M') $$
) AS ct(department_name TEXT, female_staff_count INT, male_staff_count INT);
