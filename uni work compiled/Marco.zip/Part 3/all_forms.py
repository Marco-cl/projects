from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.sql import text

app = Flask(__name__)

# Database Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:postgres@localhost/postgres'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Routes
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/query_a')
def query_a():
    departments = db.session.execute(text("""
        SELECT * FROM department WHERE location = 'E Block';
    """)).fetchall()
    return render_template('query_a.html', departments=departments)

@app.route('/query_b')
def query_b():
    modules = db.session.execute(text("""
        SELECT m.moduletitle AS title, 
               m.startdate AS start_date, 
               m.startdate + INTERVAL '3 months' AS end_date
        FROM module m
        JOIN course c ON m.courseid = c.courseid
        WHERE c.title = 'PgDIT';
    """)).fetchall()
    return render_template('query_b.html', modules=modules)

@app.route('/query_c')
def query_c():
    academic_staff = db.session.execute(text("""
        SELECT a.firstname || ' ' || a.lastname AS name, 
               a.salary, 
               d.location AS address
        FROM academicstaff a
        JOIN department d ON a.staffno = d.managerstaffno
        WHERE a.sex = 'F';
    """)).fetchall()
    return render_template('query_c.html', academic_staff=academic_staff)

@app.route('/query_d')
def query_d():
    lecturers = db.session.execute(text("""
        SELECT a.firstname || ' ' || a.lastname AS name, 
               a.sex, 
               a.salary
        FROM academicstaff a
        WHERE a.post = 'Lecturer' AND a.qualifications ILIKE '%PhD%';
    """)).fetchall()
    return render_template('query_d.html', lecturers=lecturers)

@app.route('/query_e')
def query_e():
    staff = db.session.execute(text("""
        SELECT a.lastname, 
               a.post, 
               a.qualifications
        FROM academicstaff a
        JOIN department d ON a.departmentid = d.departmentid
        WHERE d.name = 'CIS';
    """)).fetchall()
    return render_template('query_e.html', staff=staff)

@app.route('/query_f')
def query_f():
    students = db.session.execute(text("""
        SELECT s.matricno, 
               s.lastname, 
               s.sex
        FROM student s
        JOIN student_module sm ON s.matricno = sm.matricno
        JOIN module m ON sm.moduleid = m.moduleid
        WHERE m.moduletitle = 'Multi-Media'
        ORDER BY s.lastname;
    """)).fetchall()
    return render_template('query_f.html', students=students)

@app.route('/query_g')
def query_g():
    staff = db.session.execute(text("""
        SELECT staffno, 
               lastname, 
               sex, 
               post
        FROM academicstaff
        WHERE salary > (SELECT AVG(salary) FROM academicstaff);
    """)).fetchall()
    return render_template('query_g.html', staff=staff)

@app.route('/query_h')
def query_h():
    courses = db.session.execute(text("""
        SELECT c.title AS course_title, 
               COUNT(s.matricno) AS student_count
        FROM course c
        JOIN student s ON c.courseid = s.courseid
        GROUP BY c.courseid, c.title
        HAVING COUNT(s.matricno) > 10;
    """)).fetchall()
    return render_template('query_h.html', courses=courses)

@app.route('/query_i')
def query_i():
    staff_count = db.session.execute(text("""
        SELECT d.name AS department_name, 
               SUM(CASE WHEN a.sex = 'F' THEN 1 ELSE 0 END) AS female_count, 
               SUM(CASE WHEN a.sex = 'M' THEN 1 ELSE 0 END) AS male_count
        FROM academicstaff a
        JOIN department d ON a.departmentid = d.departmentid
        WHERE d.name = 'CIS'
        GROUP BY d.name;
    """)).fetchall()
    return render_template('query_i.html', staff_count=staff_count)

@app.route('/query_j')
def query_j():
    teaching_hours = db.session.execute(text("""
        SELECT a.lastname AS staff_name, 
               m.moduletitle AS module_title, 
               am.teachinghours
        FROM academicstaff_module am
        JOIN academicstaff a ON am.staffno = a.staffno
        JOIN module m ON am.moduleid = m.moduleid
        WHERE am.teachinghours > 6;
    """)).fetchall()
    return render_template('query_j.html', teaching_hours=teaching_hours)

@app.route('/query_k')
def query_k():
    department_gender = db.session.execute(text("""
        SELECT d.name AS department_name, 
               SUM(CASE WHEN a.sex = 'F' THEN 1 ELSE 0 END) AS female_count, 
               SUM(CASE WHEN a.sex = 'M' THEN 1 ELSE 0 END) AS male_count
        FROM academicstaff a
        JOIN department d ON a.departmentid = d.departmentid
        GROUP BY d.name;
    """)).fetchall()
    return render_template('query_k.html', department_gender=department_gender)

if __name__ == '__main__':
    app.run(debug=True)
