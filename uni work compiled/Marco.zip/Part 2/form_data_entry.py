from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# Database Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:postgres@localhost/postgres'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Define the Course Model
class Course(db.Model):
    __tablename__ = 'course'
    courseid = db.Column(db.String(10), primary_key=True)
    title = db.Column(db.String(100), nullable=False)

# Define the Student Model
class Student(db.Model):
    __tablename__ = 'student'
    matricNo = db.Column('matricno', db.String(10), primary_key=True)  # Maps to "matricno"
    firstName = db.Column('firstname', db.String(50), nullable=False)  # Maps to "firstname"
    lastName = db.Column('lastname', db.String(50), nullable=False)    # Maps to "lastname"
    address = db.Column('address', db.Text, nullable=False)            # Maps to "address"
    DOB = db.Column('dob', db.Date, nullable=False)                    # Maps to "dob"
    sex = db.Column('sex', db.String(1), nullable=False)               # Maps to "sex"
    financialLoan = db.Column('financialloan', db.Float, nullable=True)  # Maps to "financialloan"
    courseID = db.Column('courseid', db.String(10), db.ForeignKey('course.courseid'), nullable=True)  # Maps to "courseid"

# Route to Add a New Student
@app.route('/add-student', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        try:
            # Get data from form
            new_student = Student(
                matricNo=request.form['matricNo'],
                firstName=request.form['firstName'],
                lastName=request.form['lastName'],
                address=request.form['address'],
                DOB=request.form['DOB'],
                sex=request.form['sex'],
                financialLoan=request.form['financialLoan'],
                courseID=request.form['courseID']
            )
            db.session.add(new_student)
            db.session.commit()
            return "Student Added Successfully!"
        except Exception as e:
            db.session.rollback()
            return f"Error: {e}"
    return render_template('add_student.html')

# Initialize Database (Comment out if tables already exist)
# db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
