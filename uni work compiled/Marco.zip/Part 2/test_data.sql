-- Clear existing data from all tables
TRUNCATE TABLE student_module RESTART IDENTITY CASCADE;
TRUNCATE TABLE academicstaff_module RESTART IDENTITY CASCADE;
TRUNCATE TABLE student RESTART IDENTITY CASCADE;
TRUNCATE TABLE module RESTART IDENTITY CASCADE;
TRUNCATE TABLE course RESTART IDENTITY CASCADE;
TRUNCATE TABLE department RESTART IDENTITY CASCADE;
TRUNCATE TABLE academicstaff RESTART IDENTITY CASCADE;
-- Insert data into the 'department' table
INSERT INTO department (departmentid, name, phoneno, faxno, location, managerstaffno, managerstartdate) VALUES
    ('D001', 'School of Computing', '555-1234', '555-5678', 'Block A', NULL, NULL),
    ('D002', 'School of Data Science', '555-2345', '555-6789', 'E Block', NULL, NULL),
    ('D003', 'CIS', '555-3456', '555-7890', 'Block C', NULL, NULL);

-- Insert data into the 'academicstaff' table
INSERT INTO academicstaff (staffno, firstname, lastname, address, phoneextension, officeno, sex, salary, post, qualifications, departmentid) VALUES
    ('A001', 'John', 'Doe', '123 Elm St', '1001', 'A101', 'M', 60000.00, 'Lecturer', 'PhD', 'D001'),
    ('A002', 'Jane', 'Smith', '456 Oak St', '1002', 'B202', 'F', 65000.00, 'Senior Lecturer', 'PhD', 'D002'),
    ('A003', 'Alice', 'Brown', '789 Pine St', '1003', 'C303', 'F', 70000.00, 'Professor', 'PhD', 'D003');

-- Update managerstaffno in the 'department' table (after academicstaff has been inserted)
UPDATE department SET managerstaffno = 'A001' WHERE departmentid = 'D001';
UPDATE department SET managerstaffno = 'A002' WHERE departmentid = 'D002';
UPDATE department SET managerstaffno = 'A003' WHERE departmentid = 'D003';

-- Insert data into the 'course' table
INSERT INTO course (courseid, title) VALUES
    ('C001', 'Computer Science'),
    ('C002', 'PgDIT'),
    ('C003', 'Software Engineering'),
    ('C004', 'Information Systems'),
    ('C005', 'Artificial Intelligence');

-- Insert data into the 'module' table
INSERT INTO module (moduleid, moduletitle, startdate, courseid) VALUES
    ('M001', 'Programming Basics', '2024-01-10', 'C001'),
    ('M002', 'PgDIT', '2024-02-15', 'C002'),
    ('M003', 'Software Development', '2024-03-20', 'C003'),
    ('M004', 'Database Management', '2024-04-25', 'C004'),
    ('M005', 'multi-media', '2024-05-30', 'C005');

-- Insert data into the 'student' table
INSERT INTO student (matricno, firstname, lastname, address, dob, sex, financialloan, courseid) VALUES
    ('S001', 'Alice', 'Johnson', '1 Main St', '2000-05-15', 'F', 12000.00, 'C001'),
    ('S002', 'Bob', 'Smith', '2 Park Ave', '1998-08-20', 'M', 15000.00, 'C002'),
    ('S003', 'Charlie', 'Brown', '3 Pine Rd', '2001-04-10', 'M', 8000.00, 'C003'),
    ('S004', 'Diana', 'White', '4 Oak St', '1999-03-22', 'F', 10000.00, 'C004'),
    ('S005', 'Edward', 'Green', '5 Elm St', '2002-06-18', 'M', 5000.00, 'C005');

-- Insert data into the 'academicstaff_module' table
INSERT INTO academicstaff_module (staffno, moduleid, teachinghours) VALUES
    ('A001', 'M001', 20),
    ('A002', 'M002', 25),
    ('A003', 'M003', 30),
    ('A001', 'M004', 15),
    ('A002', 'M005', 10);

-- Insert data into the 'student_module' table
INSERT INTO student_module (matricno, moduleid, performance) VALUES
    ('S001', 'M001', 'Pass'),
    ('S002', 'M002', 'Pass'),
    ('S003', 'M003', 'Fail'),
    ('S004', 'M004', 'Pass'),
    ('S005', 'M005', 'Pass'),
    ('S001', 'M002', 'Pass'),
    ('S003', 'M004', 'Fail');