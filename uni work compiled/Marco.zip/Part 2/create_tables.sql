BEGIN;

-- Create Course Table
CREATE TABLE IF NOT EXISTS Course (
    courseID VARCHAR(10) PRIMARY KEY,
    title VARCHAR(100) NOT NULL
);

-- Create Department Table
CREATE TABLE IF NOT EXISTS Department (
    departmentID VARCHAR(10) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phoneNo VARCHAR(15),
    faxNo VARCHAR(15),
    location VARCHAR(100),
    managerStaffNo VARCHAR(10), -- No foreign key for now
    managerStartDate DATE
);

-- Create AcademicStaff Table
CREATE TABLE IF NOT EXISTS AcademicStaff (
    staffNo VARCHAR(10) PRIMARY KEY,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    address TEXT NOT NULL,
    phoneExtension VARCHAR(10),
    officeNo VARCHAR(20),
    sex CHAR(1) CHECK (sex IN ('M', 'F')),
    salary DECIMAL(10, 2),
    post VARCHAR(50),
    qualifications TEXT,
    departmentID VARCHAR(10),
    FOREIGN KEY (departmentID) REFERENCES Department(departmentID) ON DELETE NO ACTION ON UPDATE CASCADE
);

-- Add the Circular Foreign Key for managerStaffNo in Department
ALTER TABLE Department
ADD CONSTRAINT fk_managerStaffNo
FOREIGN KEY (managerStaffNo)
REFERENCES AcademicStaff(staffNo)
ON DELETE NO ACTION
ON UPDATE CASCADE;

-- Create Module Table
CREATE TABLE IF NOT EXISTS Module (
    moduleID VARCHAR(10) PRIMARY KEY,
    moduleTitle VARCHAR(100) NOT NULL,
    startDate DATE NOT NULL,
    courseID VARCHAR(10),
    FOREIGN KEY (courseID) REFERENCES Course(courseID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Create Student Table
CREATE TABLE IF NOT EXISTS Student (
    matricNo VARCHAR(10) PRIMARY KEY,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    address TEXT NOT NULL,
    DOB DATE NOT NULL,
    sex CHAR(1) CHECK (sex IN ('M', 'F')),
    financialLoan DECIMAL(10, 2),
    courseID VARCHAR(10),
    FOREIGN KEY (courseID) REFERENCES Course(courseID) ON DELETE NO ACTION ON UPDATE CASCADE
);

-- Create AcademicStaff_Module Table
CREATE TABLE IF NOT EXISTS AcademicStaff_Module (
    staffNo VARCHAR(10),
    moduleID VARCHAR(10),
    teachingHours INT CHECK (teachingHours > 0),
    PRIMARY KEY (staffNo, moduleID),
    FOREIGN KEY (staffNo) REFERENCES AcademicStaff(staffNo) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (moduleID) REFERENCES Module(moduleID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Create Student_Module Table
CREATE TABLE IF NOT EXISTS Student_Module (
    matricNo VARCHAR(10),
    moduleID VARCHAR(10),
    performance VARCHAR(10) CHECK (performance IN ('Pass', 'Fail')),
    PRIMARY KEY (matricNo, moduleID),
    FOREIGN KEY (matricNo) REFERENCES Student(matricNo) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (moduleID) REFERENCES Module(moduleID) ON DELETE CASCADE ON UPDATE CASCADE
);

END;
